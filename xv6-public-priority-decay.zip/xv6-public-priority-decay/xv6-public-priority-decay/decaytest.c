#include "types.h"
#include "stat.h"
#include "user.h"

// Busy loop (workload)
static void
heavy(int ticks)
{
  volatile int sink = 0;
  int limit = ticks * 1000000;
  if(limit < 0)
    limit = 0;

  for(int i = 0; i < limit; i++)
    sink++; // burn CPU to trigger scheduler decay

  if(sink == -1)
    printf(1, "impossible\n");
}

// Spawn a worker at given priority
static int
spawn_worker(int pr, char *label, int loops)
{
  int pid = fork();
  if(pid < 0){
    printf(1, "fork failed\n");
    exit();
  }

  if(pid == 0){
    // CHILD
    setpriority(getpid(), pr);
    printf(1, "[%s] start pid=%d pr=%d\n", label, getpid(), pr);

    for(int i = 1; i <= loops; i++){
      heavy(1);
      int cur = getpriority(getpid());
      printf(1, "[%s] pid=%d pass=%d pr=%d uptime=%d\n",
             label, getpid(), i, cur, uptime());
    }

    printf(1, "[%s] pid=%d exit\n", label, getpid());
    exit();
  }

  return pid;
}

// Print header
static void
banner(char *msg)
{
  printf(1, "\n===== %s =====\n", msg);
}

int
main(int argc, char *argv[])
{
  (void)argc;
  (void)argv;

  // ---------------------- TEST 1 --------------------------
  banner("TEST 1: Basic decay ordering");

  // High runs first, but decays over time
  int pA = spawn_worker(80, "high", 5);
  int pB = spawn_worker(20, "mid", 5);
  int pC = spawn_worker(5,  "low", 5);

  wait();
  wait();
  wait();

  // ---------------------- TEST 2 --------------------------
  banner("TEST 2: Priority aging causes lower processes to catch up");

  int pid = fork();
  if(pid == 0){
    setpriority(getpid(), 10);
    printf(1, "[aging-low] start pid=%d pr=10\n", getpid());

    for(int i = 0; i < 10; i++){
      heavy(1);
      printf(1, "[aging-low] pass=%d pr=%d\n", i, getpriority(getpid()));
    }

    printf(1, "[aging-low] exit\n");
    exit();
  }

  // Parent hogs CPU, causing child to AGE upward
  for(int i = 0; i < 10; i++)
    heavy(1);

  wait();

  // ---------------------- TEST 3 --------------------------
  banner("TEST 3: setpriority() preemption + decay interaction");

  int child = fork();
  if(child == 0){
    setpriority(getpid(), 5);
    for(int i = 0; i < 8; i++){
      heavy(1);
      printf(1, "[child-before] i=%d pr=%d\n", i, getpriority(getpid()));
    }
    printf(1, "[child-before] done\n");
    exit();
  }

  // Let child run a little
  sleep(50);

  printf(1, "Parent raising child priority to 90\n");
  setpriority(child, 90);

  wait();

  // ---------------------- TEST 4 --------------------------
  banner("TEST 4: Fairness among equal-priority + decay");

  int s1 = spawn_worker(30, "same1", 5);
  int s2 = spawn_worker(30, "same2", 5);
  int s3 = spawn_worker(30, "same3", 5);

  wait();
  wait();
  wait();

  // ---------------------- TEST 5 --------------------------
  banner("TEST 5: Starvation Prevention Check");

  int high = spawn_worker(80, "STR-high", 5);
  (void)high;

  int lowpid = fork();
  if(lowpid == 0){
    setpriority(getpid(), 0);
    for(int i = 0; i < 12; i++){
      heavy(1);
      printf(1, "[STR-low] run %d pr=%d\n", i, getpriority(getpid()));
    }
    exit();
  }

  wait();
  wait();

  // ---------------------- TEST 6 --------------------------
  banner("TEST 6: Stress Test (20 processes)");

  for(int i = 0; i < 20; i++){
    char label[16];
    label[0] = 's';
    label[1] = 't';
    label[2] = 'r';
    label[3] = '0' + (i % 10);
    label[4] = 0;
    spawn_worker(i * 3, label, 3);
  }

  for(int i = 0; i < 20; i++)
    wait();

  // ---------------------- TEST 7 --------------------------
  banner("TEST 7: exit/wait correctness");

  int wpid = fork();
  if(wpid == 0){
    setpriority(getpid(), 40);
    heavy(2);
    printf(1, "[exit-test] done\n");
    exit();
  }

  int waited = wait();
  printf(1, "Parent waited for pid=%d\n", waited);

  // ---------------------- FINAL ---------------------------
  banner("ALL TESTS FINISHED");
  exit();
}

