## Background and Motivation
- xv6 tree already has priority attribute plus `setpriority` and `printptable` syscalls along with matching user programs.
- Both schedulers (pure priority and priority-decay) are reportedly implemented, but we still lack documented, repeatable tests that demonstrate their behavior.
- Goal now is to record concrete test procedures so Executor can validate functionality, catch regressions, and eventually automate the checks.

## Key Challenges and Analysis
- Need deterministic scenarios that exercise `setpriority`/`printptable`, verifying return values, validation logic, and printed fields.
- Scheduler behavior must be observed across both repository variants (`xv6-public-priority`, `xv6-public-priority-decay`); we should reuse the same workloads where possible.
- xv6 has no unit-test harness, so tests rely on user programs plus shell scripts fed to QEMU; documenting expected outputs is crucial.
- Existing helper binaries (`loop`, `stressfs`, etc.) can generate CPU-bound load; `setpriority` itself already verifies correctness by comparing `getpriority` results.

## High-level Task Breakdown
1. **Catalog Existing Testing Hooks** ✅
   - Success: Identify which user programs (`setpriority`, `printptable`, `loop`) already exist, what arguments they expect, and what built-in validations they already perform.
2. **Design Manual/Test Script Procedure for `setpriority`**
   - Success: Document steps to run xv6, spawn processes, call `setpriority`, and verify return values/output (leveraging built-in checks plus manual inspection).
3. **Design Manual/Test Script Procedure for `printptable`**
   - Success: Provide repeatable steps plus expected output snippets confirming name/pid/state/priority printing while skipping `UNUSED`.
4. **Define Scheduler Validation Flow (Priority Scheduler)**
   - Success: Outline workload (e.g., multiple CPU-bound processes with varying priorities) and observation method showing highest priority runs first/most.
5. **Define Scheduler Validation Flow (Priority-Decay Scheduler)**
   - Success: Describe scenario demonstrating decay effect (e.g., long-running process eventually yields to others) and how to measure via timestamps or ptable prints.
6. **Summarize Automation Ideas**
   - Success: Capture scripts/commands (e.g., `expect`, `make qemu-nox < script`) to re-run tests consistently.

## Project Status Board
- [ ] Run `setpriority` test scenario
- [ ] Run `printptable` verification
- [ ] Validate priority scheduler behavior
- [ ] Validate priority-decay scheduler behavior
- [ ] Capture logs & summarize test results

## Detailed Testing Plan (Planner Notes)
### Existing Hooks / Utilities
- `setpriority` user program already validates CLI args, acceptable priority range (1–64), and ensures syscall returns previous value (via `getpriority`).
- `printptable` user program simply invokes the syscall; expect kernel to print each active process with columns {name, pid, state, priority}.
- Helper workloads: `loop` (CPU-bound), `_stressfs` (I/O bound), shell builtins (`sleep`, `kill`) available; `getpriority` syscall accessible from user space.

### `setpriority` Test Procedure
1. Launch xv6 (`make qemu-nox`).
2. Start a long-lived CPU task in background so we have a known PID:
   ```
   $ loop &
   ```
   Shell prints child PID (say `4`).
3. Run `setpriority 4 50`. Program should output:
   ```
   Old priority: <previous>
   New priority: 50
   ```
   If invalid input is given (e.g., `0` or `65`), it should print `Invalid priority value.` and exit.
4. Change priority again to confirm return value: `setpriority 4 10` → verify “Old priority: 50”.
5. Attempt setting priority for nonexistent PID to ensure syscall returns `-1` and program exits with mismatch notice (can modify program or observe kernel message).
6. Use `printptable` (next section) to visually confirm the process priority matches last update.
7. Repeat in both scheduler variants to ensure behavior consistent.

### `printptable` Test Procedure
1. With xv6 running and at least a few processes alive (`loop &`, `sleep 100`, shell), execute `printptable`.
2. Expected output per line: `<name> <pid> <state> <priority>`. Ensure there are no entries for `UNUSED`.
3. Compare before/after running `setpriority` to verify priority column updates.
4. Start/kill processes to confirm table refreshes (e.g., `loop &`, check; `kill <pid>`, `printptable` again to ensure state transitions).
5. For decay scheduler, run `printptable` periodically to observe priority values dropping as processes run.

### Priority Scheduler Validation
1. Boot xv6 priority variant.
2. Spawn three CPU-bound loops with descending priorities:
   ```
   $ loop &
   $ loop &
   $ loop &
   ```
   Note PIDs p1, p2, p3.
3. Set priorities: `setpriority p1 10`, `setpriority p2 30`, `setpriority p3 50`.
4. Use `printptable` repeatedly plus console observation; highest priority (`50`) should dominate CPU (others mostly `RUNNABLE`).
5. Optionally instrument `loop` to print timestamps or counters to quantify CPU share (or add `ticks` counter in kernel for deeper verification).
6. Success criteria: scheduler always runs process with max priority when multiple RUNNABLE tasks exist.

### Priority-Decay Scheduler Validation
1. Boot xv6 priority-decay variant.
2. Start two loops: background high priority (`setpriority p_high 64`) and low priority (`setpriority p_low 10`).
3. Observe via `printptable` that high priority initially runs (state `RUNNING`), but after repeated scheduling its priority decays (e.g., drops by 1 each time). Once priorities converge, low-priority process should get CPU time.
4. Capture timestamps by adding a `loopstat` user program printing `uptime()` every N iterations; run two copies to contrast scheduling windows.
5. Success criteria: even with initial disparity, low-priority process eventually transitions to `RUNNING`, demonstrating starvation avoidance.

### Automation / Script Ideas
- Use `script` files piped into xv6 shell:
  ```
  make qemu-nox < tests/priority_basic.script
  ```
  Script contains command sequence plus `Ctrl-a x` (or `poweroff` if implemented) at end.
- Alternatively run `expect` to parse output and assert strings (e.g., “Old priority: 50”).
- Maintain separate scripts per scheduler variant; share helper programs by copying to both trees.

## Current Status / Progress Tracking
- Executor started manual testing under `make qemu`; `setpriority` scenario in progress.
- Encountered mismatch because wrong PID was targeted; need to confirm via `printptable` before invoking syscall tests.
- Attempted to launch `make qemu-nox` automatically but command was skipped per user; waiting for go-ahead to rerun.
- Addressed reported bug: `fork()` now inherits the parent's priority instead of resetting to 32; kernel rebuild succeeded.

## Executor's Feedback or Assistance Requests
- Reminder: xv6 shell background commands print child PID, but to be safe run `printptable` (or `ps` if added) to capture the correct PID before calling `setpriority`.
- Need confirmation to proceed with automated `make qemu-nox` run, or instructions if a different test method is preferred.
- Please let me know the remaining secondary bugs so I can fix them next.

## Lessons
- _Empty._

