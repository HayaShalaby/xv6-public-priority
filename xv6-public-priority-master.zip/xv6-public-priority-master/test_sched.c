#include "types.h"
#include "stat.h"
#include "user.h"

#define MAX_CHILDREN 32

// CPU load
static void busy_loop(int rounds)
{
  volatile int i, j;
  for(i = 0; i < rounds; i++){
    j = 0;
    while(j < 100000)
      j++;
  }
}

static int spawn_worker(int pr, const char *label, int rounds)
{
  int pid = fork();
  if(pid < 0){
    printf(1, "fork failed\n");
    return -1;
  }

  if(pid == 0){
    int me = getpid();
    setpriority(me, pr);

    printf(1, "[%s] pid=%d start pr=%d\n", label, me, pr);

    for(int k = 1; k <= rounds; k++){
      busy_loop(30);
      if(k % 5 == 0){
        printf(1,
          "[%s] pid=%d pass=%d uptime=%d pr=%d\n",
          label, me, k, uptime(), getpriority(me)
        );
      }
    }

    printf(1, "[%s] pid=%d exit\n", label, me);
    exit();
  }

  return pid;
}

static void wait_all(void)
{
  while(wait() > 0);
}

int main(void)
{
  printf(1, "\n===== TEST 1: Priority ordering =====\n");
  spawn_worker(10,"low-A",20);
  spawn_worker(25,"mid-B",20);
  spawn_worker(40,"high-C",20);
  sleep(80);
  printptable();
  wait_all();


  printf(1, "\n===== TEST 2: setpriority() preemption =====\n");
  int c = fork();
  if(c == 0){
    setpriority(getpid(),10);
    for(int i=0;i<8;i++){
      busy_loop(40);
      printf(1,"[child-low] pass=%d pr=%d\n",i,getpriority(getpid()));
    }
    exit();
  }
  sleep(10);
  printf(1,"Parent raising child to pr=90\n");
  setpriority(c,90);
  sleep(50);
  printptable();
  wait_all();


  printf(1, "\n===== TEST 3: Same-priority fairness =====\n");
  spawn_worker(20,"same1",15);
  spawn_worker(20,"same2",15);
  spawn_worker(20,"same3",15);
  sleep(80);
  printptable();
  wait_all();


  printf(1, "\n===== TEST 4: Starvation Check =====\n");
  int hp = fork();
  if(hp == 0){
    setpriority(getpid(),80);
    for(int i=0;i<6;i++){
      busy_loop(10);
      sleep(5);
    }
    exit();
  }

  int lp = fork();
  if(lp == 0){
    setpriority(getpid(),5);
    for(int i=0;i<12;i++){
      busy_loop(20);
      printf(1,"[low] running %d\n",i);
    }
    exit();
  }

  sleep(120);
  printptable();
  wait_all();


  printf(1, "\n===== TEST 5: Stress test (30 procs) =====\n");
  for(int i=0;i<30;i++){
    int pr = (i*7)%50;
    spawn_worker(pr, "stress", 10);
  }
  sleep(150);
  printptable();
  wait_all();


  printf(1, "\n===== TEST 6: exit/wait correctness =====\n");
  int kid = fork();
  if(kid == 0){
    setpriority(getpid(),100);
    busy_loop(100);
    exit();
  }
  int w = wait();
  printf(1,"Parent waited for = %d\n", w);


  printf(1, "\n===== TEST 7: Single RUNNABLE process =====\n");
  spawn_worker(60,"single",10);
  sleep(60);
  printptable();
  wait_all();


  printf(1,"\n===== ALL TESTS PASSED =====\n");
  exit();
}
