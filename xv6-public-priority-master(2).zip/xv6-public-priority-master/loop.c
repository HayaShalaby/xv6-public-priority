#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
    int pr = 10;
    if(argc > 1)
        pr = atoi(argv[1]);

    setpriority(getpid(), pr);

    while(1) {
        volatile int x = 0;
        x++;  // perform some computation
    }

    exit();
}
